package com.spring.choma28Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Choma28SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Choma28SpringApplication.class, args);
	}

}
