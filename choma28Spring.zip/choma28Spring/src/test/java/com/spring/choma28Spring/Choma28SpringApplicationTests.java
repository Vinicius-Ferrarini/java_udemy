package com.spring.choma28Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Choma28SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
