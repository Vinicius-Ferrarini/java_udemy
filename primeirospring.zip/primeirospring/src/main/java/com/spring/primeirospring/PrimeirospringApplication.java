package com.spring.primeirospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeirospringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimeirospringApplication.class, args);
	}

}
